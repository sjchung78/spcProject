package bit.mirror.weibo.process;

import bit.mirror.weibo.facade.SinaWeiboCrawler;

/**
 *测试类
 *@author lins 2012-6-25
 */
public class SinaWeiboCrawlerTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SinaWeiboCrawler crawler = new SinaWeiboCrawler();
		crawler.start();
	}

}
