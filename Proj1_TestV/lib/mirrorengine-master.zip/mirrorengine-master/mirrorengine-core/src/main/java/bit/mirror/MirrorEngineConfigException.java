package bit.mirror;

public class MirrorEngineConfigException extends RuntimeException {

	private static final long serialVersionUID = 5076900659543198682L;

	public MirrorEngineConfigException() {
	}

	public MirrorEngineConfigException(String message) {
		super(message);
	}

	public MirrorEngineConfigException(Throwable cause) {
		super(cause);
	}

	public MirrorEngineConfigException(String message, Throwable cause) {
		super(message, cause);
	}

}
