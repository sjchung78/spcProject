package bit.mirror.weibo.core;

import java.util.Collection;

/**
 * 生产者接口，专门负责生产数据
 * @author lins
 * @date 2012-6-19
 **/
public interface Producer<T>{
	public T produce();
	public Collection<T> produceMega();
}
