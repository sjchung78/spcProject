package bit.mirror.frontier;

import java.net.URI;
import java.util.Date;

public class UrlVisitRecord {
	private String seedName;
	private URI url;
	private Date visitTime; // Not actually used.

	public String getSeedName() {
		return seedName;
	}

	public void setSeedName(String seedName) {
		this.seedName = seedName;
	}

	public URI getUrl() {
		return url;
	}

	public void setUrl(URI url) {
		this.url = url;
	}

	public Date getVisitTime() {
		return visitTime;
	}

	public void setVisitTime(Date visitTime) {
		this.visitTime = visitTime;
	}

}
