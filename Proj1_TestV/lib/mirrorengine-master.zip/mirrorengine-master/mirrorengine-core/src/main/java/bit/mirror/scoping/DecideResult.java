package bit.mirror.scoping;

public enum DecideResult {
	ACCEPT, REJECT, NONE
}
