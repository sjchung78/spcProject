package bit.mirror.weibo.auth;

/**
 *
 *@author  lins
 *@date 2012-6-6
 **/
public interface LoginAuth {
	public String getAccount();
	public void setAccount(String account);
	public String getPassword();
	public void setPassword(String password);
	public String getCookie();
	
}
