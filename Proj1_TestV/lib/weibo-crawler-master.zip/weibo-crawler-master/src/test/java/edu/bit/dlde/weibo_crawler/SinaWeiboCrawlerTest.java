package edu.bit.dlde.weibo_crawler;

import edu.bit.dlde.weibo_crawler.facade.SinaWeiboCrawler;

/**
 *
 *@author lins 2012-6-25
 */
public class SinaWeiboCrawlerTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SinaWeiboCrawler crawler = new SinaWeiboCrawler();
		crawler.start();
	}

}
